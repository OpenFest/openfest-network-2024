[global]
logonmodule="LogonMultisite"
logon_multisite_htpasswd="/omd/sites/openfest/etc/htpasswd"
logon_multisite_secret="/omd/sites/openfest/etc/auth.secret"
logon_multisite_serials="/omd/sites/openfest/etc/auth.serials"
logon_multisite_cookie_version=1
