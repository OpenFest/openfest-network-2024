#!/usr/bin/env python3
# encoding: utf-8

import logging
import sys

if not sys.executable.startswith('/omd'):
    sys.stdout.write("ERROR: Only executable with sites python\n")
    sys.exit(2)

sys.path.pop(0)
import cmk.utils.log
import cmk.utils.debug
from cmk.utils.exceptions import MKTerminate
from cmk.utils.config_path import LATEST_CONFIG

import cmk.base.utils
import cmk.base.config as config
from cmk.discover_plugins import PluginLocation
import cmk.base.obsolete_output as out
from cmk.base.api.agent_based.register import register_plugin_by_type
import cmk.base.check_api as check_api
import cmk.base.ip_lookup as ip_lookup
from cmk.checkengine.submitters import get_submitter

import cmk.base.plugins.agent_based.datapower_tcp
import cmk.plugins.collection.agent_based.mounts
import cmk.base.plugins.agent_based.hpux_cpu
import cmk.base.plugins.agent_based.cpu_load
import cmk.base.plugins.agent_based.arbor_pravail
import cmk.base.plugins.agent_based.winperf_tcp_conn
import cmk.base.plugins.agent_based.ucd_cpu_load
import cmk.base.plugins.agent_based.tcp_conn_stats
import cmk.base.plugins.agent_based.lnx_if
import cmk.base.plugins.agent_based.checkmk_cached_plugins
import cmk.base.plugins.agent_based.prometheus_cpu
import cmk.base.plugins.agent_based.cpu
import cmk.base.plugins.agent_based.prometheus_uptime
import cmk.base.plugins.agent_based.mcafee_emailgateway_cpuload
import cmk.base.plugins.agent_based.kernel
import cmk.base.plugins.agent_based.statgrab_load
import cmk.base.plugins.agent_based.cmk_update_agent_status
import cmk.base.plugins.agent_based.checkmk_agent
import cmk.base.plugins.agent_based.lnx_bonding
import cmk.base.plugins.agent_based.section_lnx_container_host_if
import cmk.base.plugins.agent_based.cpu_threads
import cmk.base.plugins.agent_based.snmp_uptime
import cmk.base.plugins.agent_based.arbor_peakflow_tms
import cmk.base.plugins.agent_based.arbor_peakflow_sp
import cmk.base.plugins.agent_based.uptime
import cmk.base.plugins.agent_based.kube_uptime
import cmk.base.plugins.agent_based.check_mk
import cmk.base.plugins.agent_based.mem
import cmk.base.plugins.agent_based.checkmk_agent_plugins
import cmk.base.plugins.agent_based.windows_os_bonding
import cmk.base.plugins.agent_based.cmk_agent_ctl_status
register_plugin_by_type(PluginLocation(module='cmk.plugins.collection.agent_based.mounts', name='agent_section_mounts'), cmk.plugins.collection.agent_based.mounts.agent_section_mounts)
register_plugin_by_type(PluginLocation(module='cmk.plugins.collection.agent_based.mounts', name='check_plugin_mounts'), cmk.plugins.collection.agent_based.mounts.check_plugin_mounts)
cmk.base.utils.register_sigint_handler()

# very simple commandline parsing: only -v (once or twice) and -d are supported

cmk.utils.log.setup_console_logging()
logger = logging.getLogger("cmk.base")

# TODO: This is not really good parsing, because it not cares about syntax like e.g. "-nv".
#       The later regular argument parsing is handling this correctly. Try to clean this up.
cmk.utils.log.logger.setLevel(cmk.utils.log.verbosity_to_log_level(len([ a for a in sys.argv if a in [ "-v", "--verbose"] ])))

if '-d' in sys.argv:
    cmk.utils.debug.enable()

config.load_checks(check_api.get_check_api_context, [
    '/omd/sites/openfest/share/check_mk/checks/kernel',
    '/omd/sites/openfest/share/check_mk/checks/mem_linux',
])
config.load_packed_config(LATEST_CONFIG)
config.ipaddresses = {'ap-lector-b': '10.20.0.55'}

config.ipv6addresses = {}

try:
    # mode_check is `mode --check hostname`
    from cmk.base.modes.check_mk import mode_check
    sys.exit(
        mode_check(
            get_submitter,
            {},
           ['ap-lector-b'],
            active_check_handler=lambda *args: None,
            keepalive=False,
            precompiled_host_check=True,
        )
    )
except MKTerminate:
    out.output('<Interrupted>\n', stream=sys.stderr)
    sys.exit(1)
except SystemExit as e:
    sys.exit(e.code)
except Exception as e:
    import traceback, pprint
    sys.stdout.write("UNKNOWN - Exception in precompiled check: %s (details in long output)\n" % e)
    sys.stdout.write("Traceback: %s\n" % traceback.format_exc())

    sys.exit(3)
