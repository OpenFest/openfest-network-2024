#!/usr/bin/env python3
# encoding: utf-8

import logging
import sys

if not sys.executable.startswith('/omd'):
    sys.stdout.write("ERROR: Only executable with sites python\n")
    sys.exit(2)

sys.path.pop(0)
import cmk.utils.log
import cmk.utils.debug
from cmk.utils.exceptions import MKTerminate
from cmk.utils.config_path import LATEST_CONFIG

import cmk.base.utils
import cmk.base.config as config
from cmk.discover_plugins import PluginLocation
import cmk.base.obsolete_output as out
from cmk.base.api.agent_based.register import register_plugin_by_type
import cmk.base.check_api as check_api
import cmk.base.ip_lookup as ip_lookup
from cmk.checkengine.submitters import get_submitter

import cmk.base.plugins.agent_based.if64_tplink
import cmk.base.plugins.agent_based.uptime
import cmk.base.plugins.agent_based.prometheus_uptime
import cmk.base.plugins.agent_based.snmp_info
import cmk.base.plugins.agent_based.if_statgrab_net
import cmk.base.plugins.agent_based.vms_if
import cmk.base.plugins.agent_based.aix_if
import cmk.base.plugins.agent_based.hp_msa_if
import cmk.base.plugins.agent_based.if32
import cmk.base.plugins.agent_based.if_fortigate
import cmk.base.plugins.agent_based.if64_basic
import cmk.base.plugins.agent_based.kube_uptime
import cmk.base.plugins.agent_based.ucs_bladecenter_if
import cmk.base.plugins.agent_based.emc_vplex_if
import cmk.base.plugins.agent_based.snmp_uptime
import cmk.base.plugins.agent_based.if_brocade_lancom
cmk.base.utils.register_sigint_handler()

# very simple commandline parsing: only -v (once or twice) and -d are supported

cmk.utils.log.setup_console_logging()
logger = logging.getLogger("cmk.base")

# TODO: This is not really good parsing, because it not cares about syntax like e.g. "-nv".
#       The later regular argument parsing is handling this correctly. Try to clean this up.
cmk.utils.log.logger.setLevel(cmk.utils.log.verbosity_to_log_level(len([ a for a in sys.argv if a in [ "-v", "--verbose"] ])))

if '-d' in sys.argv:
    cmk.utils.debug.enable()

config.load_checks(check_api.get_check_api_context, [])
config.load_packed_config(LATEST_CONFIG)
config.ipaddresses = {'sw-voc-a': '10.20.0.21'}

config.ipv6addresses = {}

try:
    # mode_check is `mode --check hostname`
    from cmk.base.modes.check_mk import mode_check
    sys.exit(
        mode_check(
            get_submitter,
            {},
           ['sw-voc-a'],
            active_check_handler=lambda *args: None,
            keepalive=False,
            precompiled_host_check=True,
        )
    )
except MKTerminate:
    out.output('<Interrupted>\n', stream=sys.stderr)
    sys.exit(1)
except SystemExit as e:
    sys.exit(e.code)
except Exception as e:
    import traceback, pprint
    sys.stdout.write("UNKNOWN - Exception in precompiled check: %s (details in long output)\n" % e)
    sys.stdout.write("Traceback: %s\n" % traceback.format_exc())

    sys.exit(3)
