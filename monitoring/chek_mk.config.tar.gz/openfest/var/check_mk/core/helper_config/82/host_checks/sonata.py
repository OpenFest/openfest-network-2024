#!/usr/bin/env python3
# encoding: utf-8

import logging
import sys

if not sys.executable.startswith('/omd'):
    sys.stdout.write("ERROR: Only executable with sites python\n")
    sys.exit(2)

sys.path.pop(0)
import cmk.utils.log
import cmk.utils.debug
from cmk.utils.exceptions import MKTerminate
from cmk.utils.config_path import LATEST_CONFIG

import cmk.base.utils
import cmk.base.config as config
from cmk.discover_plugins import PluginLocation
import cmk.base.obsolete_output as out
from cmk.base.api.agent_based.register import register_plugin_by_type
import cmk.base.check_api as check_api
import cmk.base.ip_lookup as ip_lookup
from cmk.checkengine.submitters import get_submitter

import cmk.base.plugins.agent_based.inventory_solaris_routes
import cmk.base.plugins.agent_based.statgrab_load
import cmk.base.plugins.agent_based.inventory_win_reg_uninstall
import cmk.base.plugins.agent_based.tcp_conn_stats
import cmk.base.plugins.agent_based.inventory_enviromux_micro
import cmk.base.plugins.agent_based.juniper_info
import cmk.base.plugins.agent_based.ntp
import cmk.base.plugins.agent_based.inventory_aix_service_packs
import cmk.base.plugins.agent_based.lparstat_aix
import cmk.base.plugins.agent_based.suseconnect
import cmk.base.plugins.agent_based.inventory_kyocera_printer
import cmk.base.plugins.agent_based.inventory_lnx_sysctl
import cmk.base.plugins.agent_based.kube_deployment_info
import cmk.base.plugins.agent_based.docker_container_diskstat
import cmk.base.plugins.agent_based.lnx_thermal
import cmk.base.plugins.agent_based.snmp_info
import cmk.base.plugins.agent_based.oracle_dataguard_stats
import cmk.plugins.netapp.agent_based.netapp_ontap_info
import cmk.base.plugins.agent_based.mem_used
import cmk.base.plugins.agent_based.ibm_mq_queues
import cmk.base.plugins.agent_based.lnx_if
import cmk.base.plugins.agent_based.inventory_fortisandbox_software
import cmk.base.plugins.agent_based.inventory_win_bios
import cmk.base.plugins.agent_based.winperf_tcp_conn
import cmk.base.plugins.agent_based.quantum_storage
import cmk.base.plugins.agent_based.datapower_tcp
import cmk.base.plugins.agent_based.inventory_solaris_psrinfo
import cmk.base.plugins.agent_based.df_section
import cmk.base.plugins.agent_based.inventory_checkpoint_vpn_tunnels
import cmk.base.plugins.agent_based.inventory_docker_container_network
import cmk.base.plugins.agent_based.inv_esx_vsphere_hostsystem
import cmk.base.plugins.agent_based.ibm_mq_managers
import cmk.base.plugins.agent_based.ipmi
import cmk.base.plugins.agent_based.inventory_win_wmi_updates
import cmk.base.plugins.agent_based.inventory_mobileiron
import cmk.base.plugins.agent_based.inventory_win_video
import cmk.base.plugins.agent_based.kube_pod_containers
import cmk.base.plugins.agent_based.lnx_distro
import cmk.base.plugins.agent_based.solaris_uname
import cmk.base.plugins.agent_based.dell_hw_info
import cmk.plugins.azure.agent_based.azure_load_balancer
import cmk.base.plugins.agent_based.arbor_peakflow_sp
import cmk.base.plugins.agent_based.winperf_if
import cmk.base.plugins.agent_based.inventory_snmp_extended_info
import cmk.base.plugins.agent_based.inventory_win_wmi_software
import cmk.base.plugins.agent_based.systemd_units
import cmk.base.plugins.agent_based.inventory_docker_container_node_name
import cmk.base.plugins.agent_based.esx_vsphere_hostsystem_section
import cmk.base.plugins.agent_based.inventory_aix_packages
import cmk.base.plugins.agent_based.inventory_primekey
import cmk.base.plugins.agent_based.docker_container_diskstat_cgroupv2
import cmk.base.plugins.agent_based.inventory_kube_node
import cmk.base.plugins.agent_based.inv_cisco_vlans
import cmk.base.plugins.agent_based.oracle_instance_section
import cmk.base.plugins.agent_based.inventory_kube_namespace
import cmk.base.plugins.agent_based.ibm_mq_channels
import cmk.base.plugins.agent_based.cpu_load
import cmk.base.plugins.agent_based.oracle_tablespaces
import cmk.plugins.netapp.agent_based.netapp_ontap_disk
import cmk.base.plugins.agent_based.inventory_fortisandbox_system
import cmk.base.plugins.agent_based.inventory_win_exefiles
import cmk.base.plugins.agent_based.uptime
import cmk.base.plugins.agent_based.allnet_ip_sensoric
import cmk.base.plugins.agent_based.cisco_meraki_org_device_info
import cmk.base.plugins.agent_based.prometheus_uptime
import cmk.base.plugins.agent_based.docker_container_mem_cgroupv2
import cmk.base.plugins.agent_based.inventory_citrix_controller
import cmk.base.plugins.agent_based.lnx_uname
import cmk.base.plugins.agent_based.checkmk_cached_plugins
import cmk.base.plugins.agent_based.inv_if
import cmk.base.plugins.agent_based.hr_mem
import cmk.base.plugins.agent_based.omd_status
import cmk.base.plugins.agent_based.inventory_win_ip_r
import cmk.base.plugins.agent_based.oracle_recovery_area
import cmk.base.plugins.agent_based.oracle_performance_inventory
import cmk.base.plugins.agent_based.win_system
import cmk.base.plugins.agent_based.hp_proliant_da_phydrv
import cmk.base.plugins.agent_based.cmk_site_statistics
import cmk.base.plugins.agent_based.kube_node_kubelet
import cmk.base.plugins.agent_based.lnx_cpuinfo
import cmk.base.plugins.agent_based.kernel
import cmk.base.plugins.agent_based.kube_daemonset_info
import cmk.base.plugins.agent_based.checkmk_agent_plugins
import cmk.base.plugins.agent_based.prtconf
import cmk.plugins.netapp.agent_based.netapp_ontap_cpu
import cmk.base.plugins.agent_based.inventory_checkmk_server
import cmk.base.plugins.agent_based.inventory_kube_deployment
import cmk.base.plugins.agent_based.diskstat_statgrab_section
import cmk.base.plugins.agent_based.windows_os_bonding
import cmk.base.plugins.agent_based.infoblox_osinfo
import cmk.base.plugins.agent_based.mem
import cmk.base.plugins.agent_based.snmp_uptime
import cmk.base.plugins.agent_based.df
import cmk.base.plugins.agent_based.esx_vsphere_systeminfo
import cmk.base.plugins.agent_based.cmk_update_agent_status
import cmk.base.plugins.agent_based.cmk_agent_ctl_status
import cmk.base.plugins.agent_based.inventory_lnx_video
import cmk.base.plugins.agent_based.inventory_aix_baselevel
import cmk.base.plugins.agent_based.oracle_instance_inventory
import cmk.base.plugins.agent_based.prometheus_cpu
import cmk.base.plugins.agent_based.win_cpuinfo
import cmk.base.plugins.agent_based.cpu_threads
import cmk.base.plugins.agent_based.inventory_lnx_packages
import cmk.base.plugins.agent_based.inventory_citrix_state
import cmk.base.plugins.agent_based.ucd_cpu_load
import cmk.base.plugins.agent_based.fireeye_sys_status
import cmk.base.plugins.agent_based.kube_cluster_info
import cmk.base.plugins.agent_based.inventory_win_networkadapter
import cmk.base.plugins.agent_based.inventory_kube_pod
import cmk.base.plugins.agent_based.inventory_win_disks
import cmk.base.plugins.agent_based.mobileiron_section
import cmk.base.plugins.agent_based.diskstat
import cmk.base.plugins.agent_based.inventory_kube_cronjob
import cmk.base.plugins.agent_based.inventory_esx_vsphere_clusters
import cmk.base.plugins.agent_based.cpu
import cmk.base.plugins.agent_based.inventory_solaris_addresses
import cmk.base.plugins.agent_based.inventory_aix_lparstat
import cmk.base.plugins.agent_based.check_mk
import cmk.base.plugins.agent_based.cisco_meraki_org_device_status
import cmk.base.plugins.agent_based.inventory_azure_load_balancer
import cmk.base.plugins.agent_based.inventory_lnx_ip_r
import cmk.base.plugins.agent_based.multipath
import cmk.base.plugins.agent_based.hpux_cpu
import cmk.base.plugins.agent_based.mcafee_emailgateway_cpuload
import cmk.base.plugins.agent_based.hp_proliant_systeminfo
import cmk.base.plugins.agent_based.win_computersystem
import cmk.base.plugins.agent_based.perle_psmu
import cmk.base.plugins.agent_based.arbor_pravail
import cmk.base.plugins.agent_based.omd_diskusage
import cmk.base.plugins.agent_based.omd_info
import cmk.base.plugins.agent_based.perle_chassis_slots
import cmk.base.plugins.agent_based.fritz
import cmk.base.plugins.agent_based.inventory_ipmi_firmware
import cmk.base.plugins.agent_based.inventory_oracle_systemparameter
import cmk.base.plugins.agent_based.mem_used_sections
import cmk.base.plugins.agent_based.mssql_instance
import cmk.base.plugins.agent_based.checkmk_agent
import cmk.base.plugins.agent_based.inventory_fortiauthenticator_system
import cmk.base.plugins.agent_based.inventory_kube_daemonset
import cmk.base.plugins.agent_based.kube_statefulset_info
import cmk.base.plugins.agent_based.inventory_esx_vsphere_virtual_machines
import cmk.base.plugins.agent_based.aruba_wlc_aps
import cmk.base.plugins.agent_based.arbor_peakflow_tms
import cmk.base.plugins.agent_based.inventory_fortimail_system
import cmk.plugins.collection.agent_based.mounts
import cmk.base.plugins.agent_based.livestatus_status
import cmk.base.plugins.agent_based.oracle_performance_section
import cmk.base.plugins.agent_based.inventory_docker_node_network
import cmk.base.plugins.agent_based.inventory_kube_cluster
import cmk.base.plugins.agent_based.inventory_fortinet_firewall
import cmk.base.plugins.agent_based.docker_container_mem
import cmk.base.plugins.agent_based.inventory_kube_statefulset
import cmk.base.plugins.agent_based.kube_uptime
import cmk.base.plugins.agent_based.hp_proliant_mem
import cmk.base.plugins.agent_based.inventory_solaris_pkginfo
import cmk.base.plugins.agent_based.win_os
import cmk.base.plugins.agent_based.inventory_docker_node_images
import cmk.base.plugins.agent_based.kube_cronjob_info
import cmk.base.plugins.agent_based.lnx_bonding
import cmk.base.plugins.agent_based.inventory_docker_container_labels
import cmk.base.plugins.agent_based.win_computersystemproduct
import cmk.base.plugins.agent_based.infoblox_systeminfo
import cmk.base.plugins.agent_based.inventory_fortigate_ha
import cmk.base.plugins.agent_based.inventory_dmidecode
import cmk.base.plugins.agent_based.kube_replicas
import cmk.base.plugins.agent_based.netapp_api_info
import cmk.base.plugins.agent_based.section_lnx_container_host_if
import cmk.base.plugins.agent_based.perle_chassis
import cmk.base.plugins.agent_based.kube_namespace_info
import cmk.base.plugins.agent_based.docker_node_info
import cmk.base.plugins.agent_based.inventory_couchbase_node_ports
import cmk.base.plugins.agent_based.kube_node_info
import cmk.base.plugins.agent_based.inventory_mssql_clusters
import cmk.base.plugins.agent_based.omd_apache
import cmk.base.plugins.agent_based.solaris_prtdiag
import cmk.base.plugins.agent_based.kube_pod_info
import cmk.base.plugins.agent_based.netapp_api_disk
import cmk.base.plugins.agent_based.inventory_lnx_block_devices
register_plugin_by_type(PluginLocation(module='cmk.plugins.azure.agent_based.azure_load_balancer', name='agent_section_azure_loadbalancers'), cmk.plugins.azure.agent_based.azure_load_balancer.agent_section_azure_loadbalancers)
register_plugin_by_type(PluginLocation(module='cmk.plugins.collection.agent_based.mounts', name='agent_section_mounts'), cmk.plugins.collection.agent_based.mounts.agent_section_mounts)
register_plugin_by_type(PluginLocation(module='cmk.plugins.collection.agent_based.mounts', name='check_plugin_mounts'), cmk.plugins.collection.agent_based.mounts.check_plugin_mounts)
register_plugin_by_type(PluginLocation(module='cmk.plugins.netapp.agent_based.netapp_ontap_cpu', name='agent_section_netapp_ontap_cpu'), cmk.plugins.netapp.agent_based.netapp_ontap_cpu.agent_section_netapp_ontap_cpu)
register_plugin_by_type(PluginLocation(module='cmk.plugins.netapp.agent_based.netapp_ontap_disk', name='agent_section_netapp_ontap_disk'), cmk.plugins.netapp.agent_based.netapp_ontap_disk.agent_section_netapp_ontap_disk)
register_plugin_by_type(PluginLocation(module='cmk.plugins.netapp.agent_based.netapp_ontap_disk', name='inventory_plugin_netapp_ontap_disk'), cmk.plugins.netapp.agent_based.netapp_ontap_disk.inventory_plugin_netapp_ontap_disk)
register_plugin_by_type(PluginLocation(module='cmk.plugins.netapp.agent_based.netapp_ontap_info', name='inventory_plugin_netapp_ontap_info'), cmk.plugins.netapp.agent_based.netapp_ontap_info.inventory_plugin_netapp_ontap_info)
cmk.base.utils.register_sigint_handler()

# very simple commandline parsing: only -v (once or twice) and -d are supported

cmk.utils.log.setup_console_logging()
logger = logging.getLogger("cmk.base")

# TODO: This is not really good parsing, because it not cares about syntax like e.g. "-nv".
#       The later regular argument parsing is handling this correctly. Try to clean this up.
cmk.utils.log.logger.setLevel(cmk.utils.log.verbosity_to_log_level(len([ a for a in sys.argv if a in [ "-v", "--verbose"] ])))

if '-d' in sys.argv:
    cmk.utils.debug.enable()

config.load_checks(check_api.get_check_api_context, [
    '/omd/sites/openfest/share/check_mk/checks/docker_node_info',
    '/omd/sites/openfest/share/check_mk/checks/ibm_mq_channels',
    '/omd/sites/openfest/share/check_mk/checks/ibm_mq_managers',
    '/omd/sites/openfest/share/check_mk/checks/ibm_mq_queues',
    '/omd/sites/openfest/share/check_mk/checks/kernel',
    '/omd/sites/openfest/share/check_mk/checks/lparstat_aix',
    '/omd/sites/openfest/share/check_mk/checks/mem_linux',
    '/omd/sites/openfest/share/check_mk/checks/mkeventd_status',
    '/omd/sites/openfest/share/check_mk/checks/mssql_instance',
    '/omd/sites/openfest/share/check_mk/checks/netapp_api_info',
    '/omd/sites/openfest/share/check_mk/checks/omd_apache',
    '/omd/sites/openfest/share/check_mk/checks/oracle_dataguard_stats',
    '/omd/sites/openfest/share/check_mk/checks/oracle_recovery_area',
    '/omd/sites/openfest/share/check_mk/checks/perle_chassis',
    '/omd/sites/openfest/share/check_mk/checks/perle_chassis_slots',
    '/omd/sites/openfest/share/check_mk/checks/perle_psmu',
    '/omd/sites/openfest/share/check_mk/checks/suseconnect',
])
config.load_packed_config(LATEST_CONFIG)
config.ipaddresses = {'sonata': '127.0.0.1'}

config.ipv6addresses = {}

try:
    # mode_check is `mode --check hostname`
    from cmk.base.modes.check_mk import mode_check
    sys.exit(
        mode_check(
            get_submitter,
            {},
           ['sonata'],
            active_check_handler=lambda *args: None,
            keepalive=False,
            precompiled_host_check=True,
        )
    )
except MKTerminate:
    out.output('<Interrupted>\n', stream=sys.stderr)
    sys.exit(1)
except SystemExit as e:
    sys.exit(e.code)
except Exception as e:
    import traceback, pprint
    sys.stdout.write("UNKNOWN - Exception in precompiled check: %s (details in long output)\n" % e)
    sys.stdout.write("Traceback: %s\n" % traceback.format_exc())

    sys.exit(3)
